Will Bartlett (wab73) and Josh Hagins
Computer Vision - CS 4670
Project 1

No detailed information for executable necessary, runs as previously built.
All required functionality implemented.  In addition:
-Brush, filter by brush, scissor by brush (whistle #1)
-Blurring (whistle #2)

To disable blurring, set the const variable blur in LiveWireDP to false.

We also believe our edge algorithm is more efficient than most because exploit symmetry.
